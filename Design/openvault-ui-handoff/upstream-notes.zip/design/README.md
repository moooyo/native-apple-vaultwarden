# 设计源文件

- `boards/*.dc.html`：每个文件是一个画板（一屏或一个状态组），来自设计画布 https://claude.ai/artifact/V7Wv2b5aVKsmLTY33LMghN 。
- `ov-kit.css`：所有画板共用的样式。`--accent`、`--label`、`--label2`、`--sep`、`--card`、`--bg` 等变量对应 iOS / macOS 系统语义色；`.dark` 是深色模式，`.hc` 是增强对比度，`.mac` 是 macOS 字号。
- `canvas.json`：画板清单、标题、尺寸和在画布上的排布。

读法：

1. `<x-dc>…</x-dc>` 里是界面结构和文案。
2. `{{名字}}` 由文件末尾 `<script type="text/x-dc">` 里 `class Component` 的 `renderVals()` 提供；`<sc-if value="{{x}}">` 是条件显示，`<sc-for list="{{xs}}" as="x">` 是重复。
3. 点击、输入、计时等交互是 `renderVals()` 返回的函数（`onClick="{{fn}}"`、`onInput="{{fn}}"`），状态保存在 `this.state`。
4. 画板依赖画布运行时（`support.js`），不能直接用浏览器打开；需要看效果时打开上面的画布链接。
5. 所有人名、条目、链接都是演示数据。
