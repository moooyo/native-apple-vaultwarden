# OpenVault UI 重新设计 · 实现交接

这份文档交给 Claude Code，在 `moooyo/native-apple-vaultwarden` 仓库里实现新版 UI。目标平台：iOS 27、iPadOS 27、macOS 27（Liquid Glass）。

- 设计画布（可交互，所有状态都能点）：https://claude.ai/artifact/V7Wv2b5aVKsmLTY33LMghN
- 本包内容：
  - `HANDOFF.md`：本文件，实现时以它为准。
  - `design/boards/*.dc.html`：39 个画板的源码，是结构、文案、状态和交互的权威来源。
  - `design/ov-kit.css`：画板共用样式，颜色变量即系统色，见第 3 节。
  - `design/canvas.json`：画板清单与标题。

## 0. 给实现者的说明

**读取顺序。** 先看本文件对应章节，再打开同名画板源码核对细节。规范表格（第 9、10 节）来自画布里的“设计规范”画板。

**怎么读画板源码。**
- `<x-dc>` 里是界面结构和文案，`class` 对应 `design/ov-kit.css`。
- `{{名字}}` 的值来自文件底部 `<script>` 里 `renderVals()` 的返回值；`<sc-if>` 是条件显示，`<sc-for>` 是列表。
- 交互逻辑（点击、计时、校验、撤销）都写在 `renderVals()` 返回的函数里。
- 画板里的人名、条目、链接都是演示数据（同一个账户：16 个条目、5 个验证码、3 个 Send），不要写进代码。
- 画板不能脱离画布单独打开，要看效果请用上面的画布链接。

**实现原则。**
1. 优先用系统控件：`List`、`Form`、`Section`、`Toolbar`、`Menu`、`.alert`、`.confirmationDialog`、`.sheet`、`NavigationSplitView`、`TabView`。设计稿用于说明结构、层级和行为，不要照着 HTML 像素手绘控件。
2. 只用系统语义色（第 3 节），不建自定义 AccentColor；必须支持深色模式、增强对比度、动态字体。
3. Liquid Glass 只出现在导航与控件层（标签栏、工具栏、侧栏、Sheet、菜单、提示框、操作结果提示），内容区不透明，不加装饰性光晕。
4. 说明文字从严：不解释手势、不重复安全承诺、不显示服务器地址和自动锁定时间；只保留确认框里的后果说明、空状态和会影响选择的限制。
5. 拷贝反馈：点按用户名 / 密码 / 验证码整行直接拷贝，不弹菜单、不弹 Toast，在被点的那一行就地显示“已拷贝”1.6 秒。底部玻璃提示只用于操作结果（如“已移到回收站”），可带“撤销”。
6. 验证码倒计时：不用圆环，用贴在行底部、宽 3pt、随时间从满到空的进度条；剩余 ≤5 秒变橙色。

**每个阶段完成后自检。**
- `swift build` 和受影响模块的 `swift run <Module>Tests`。注意：本仓库的测试是可执行目标，用 `swift run`，不是 `swift test`。
- 界面改动跑 `Tests/Interface` 的模拟器 UI 测试，iPhone、iPad 各跑一次，命令见 `App/README.md`。

## 1. 信息架构与导航

### iPhone（`App/iOS/UI/MainTabView.swift`、`RootView.swift`）
- **标签栏：** 左侧一组四个标签：保险库 / 验证码 / Send / 生成器，用实心图标（`.fill`），滚动时收起（`.tabBarMinimizeBehavior(.onScrollDown)`）。
- **账户头像按钮：** 标签栏右侧单独一个圆形玻璃按钮，显示账户头像（姓名首字母），点开是设置页；在设置页时头像外圈加强调色描边。
  - 实现：系统只把 `role: .search` 的标签单独做成圆形，所以借用它放头像：`Tab(value: .account, role: .search) { SettingsView() } label: { 头像 }`。
  - 无障碍名称设为“账户与设置”；设置页里不加 `.searchable`。
- **各标签首页的顶部：**
  - 不放导航栏那一行，也不放头像。
  - 大标题与页面操作在同一行，标题在左，操作按钮在右侧垂直居中。
  - 保险库：搜索（独立玻璃圆钮）+［排序与筛选 | 新建］（一组）。
  - 验证码：新建。Send：新建。生成器：历史。
- **搜索：** 只在保险库提供，由工具栏按钮唤起 `.searchable(text:isPresented:)`。搜索框在顶部，右侧是“取消”，标签栏保持在“保险库”。
- **推入的子页面：** 条目详情、文件夹、回收站与归档、文件夹管理、导入与导出。顶栏左侧为返回按钮，标签栏保留。
- **以 Sheet 呈现：** 新建条目、新建 Send、生成历史、Send 详情。

### iPad（与 iPhone 共用 `MainTabView`；删除 `OpenVaultPadWorkspace.swift` 分支）
- **TabView：** `TabView` + `.tabViewStyle(.sidebarAdaptable)`。
- **顶栏（同一行）：**
  - 左上角是侧栏开关。
  - 中间是悬浮标签栏（四个标签），右侧是账户头像圆钮。
  - 每一栏自己的工具栏按钮放在这一行，靠该栏右端。大标题在下一行，右侧不放按钮。
- **侧栏（悬浮玻璃，内缩 10pt、圆角 18pt）：**
  - 标签：保险库 / 验证码 / Send / 生成器。
  - “类型”：登录、银行卡、身份、安全笔记、SSH 密钥。
  - “文件夹”：标题右侧 + 新建。
  - “隐藏的条目”：归档、回收站。
  - 底部账户行：头像、姓名、邮箱，点开进入设置。
- **侧栏显示时：** 内容区右移让出位置，不被遮挡；类型标签条只在侧栏隐藏时显示。
- **侧栏筛选：** 类型、文件夹、归档、回收站都是保险库列表的筛选，不另开页面。
- **搜索：** 按钮在保险库列表栏工具栏（与排序、新建同组）。

### Mac（`App/macOS/`）
- **主窗口（`MacRootView`、`MacMainView`）：** `NavigationSplitView` 三栏，系统侧栏会自动成为悬浮玻璃面板。
  - 不要给侧栏或分栏加 `.background`。删除 `MacMainView.swift` 约 196 行的 `.background(MacOpenVaultStyle.detail)`，以及侧栏的 `.safeAreaBar` 账户页脚。
- **侧栏（`MacSidebarView`）：**
  - 全部条目、置顶、验证码。
  - 类型：登录、银行卡、身份、安全笔记、SSH 密钥。
  - 文件夹：标题旁 + 新建，右键可重命名或删除。
  - 工具：Send、生成器。
  - 隐藏的条目：归档、回收站。
  - 每行带计数 `.badge`。
- **登录窗口：** 登录是独立的紧凑窗口（560×500，固定尺寸），不放进 1260×780 的主窗口。
- **设置：** 用 `Settings` 场景（⌘,）：通用 / 账户 / 安全 / 同步 / 自动填充。
- **菜单栏面板：** `MenuBarExtra(...).menuBarExtraStyle(.window)`，由“通用”面板的开关控制是否显示。

## 2. 全局交互规则

- **拷贝：** 整行可点即拷贝，行内“已拷贝”1.6 秒（iOS 在行尾，Mac 在值右侧）。剪贴板按设置的时间清除，要用 `UIPasteboard` 的 `expirationDate` 或 macOS 对应机制。
- **密码显示：**
  - iOS 用眼睛按钮切换显示。显示时数字用蓝色、符号用橙色，字母用正文色。
  - Mac 鼠标悬停（或键盘焦点）时显示明文，移开恢复圆点，同时保留点按拷贝。
- **验证码：** 大号等宽字体，每 3 位一组；底部 3pt 进度条递减，≤5 秒变橙；整行点按拷贝。
- **破坏性操作：**
  - 移到回收站、归档：立即执行，底部提示可撤销（约 4 秒）。
  - 永久删除、清空回收站、退出登录、删除 Send：一律先确认，确认框写清后果，破坏性按钮为红色。
- **表单完成按钮：** 必填项为空时停用（如新建条目的名称、登录的邮箱和主密码）。
- **菜单：** 排序、更多、共享、文件夹操作都用玻璃菜单，从对应按钮弹出；单选项用勾号。
- **焦点环：** 只出现在真正获得焦点的那个输入框上，不包住整组。
- **滚动指示器：** 用系统默认，不要额外显示滚动条。

## 3. 设计 Token

颜色全部用系统色，见第 9 节的色板、语义和增强对比度结果。字号与间距如下：

**iOS / iPadOS 字号**（对应系统文字样式，需支持动态字体）

| 用途 | 画板 class | 字号 / 行高 / 字重 | SwiftUI |
|---|---|---|---|
| 大标题 | `.lt` | 34 / 41 / Bold | `.largeTitle.bold()` |
| 页面/详情标题 | `.t1` | 28 / 34 / Bold | `.title.bold()` |
| 次级标题 | `.t2` | 22 / 28 / Bold | `.title2.bold()` |
| 分组标题 | `.t3` | 20 / 25 / Semibold | `.title3.weight(.semibold)` |
| 行标题 | `.hl` | 17 / 22 / Semibold | `.headline` |
| 正文 | `.bd` | 17 / 22 | `.body` |
| 说明 | `.co` | 16 / 21 | `.callout` |
| 副标题 | `.sh` | 15 / 20 | `.subheadline` |
| 脚注、字段标签 | `.fn` `.flabel` | 13 / 18 | `.footnote` |
| 标签栏文字 | `.tab` | 10 / 12 / Semibold | 系统标签栏 |

**macOS 字号**：正文与侧栏 13，侧栏分组标题 11（Semibold、次要色），窗口/工具栏标题 15（Semibold），详情标题 26（Bold），次要说明 11–12。

**尺寸与间距**
- **iOS 分组卡片：** 圆角 26、左右边距 16、行最小高 52；大标题左边距 20；分组标题与卡片间距 10；分组之间 16–24。
- **iOS 控件：** 触控目标 ≥44pt；顶部玻璃按钮 44×44；分组胶囊按钮高 44；标签栏高 62，左右内缩 21，离底 25。
- **iPad：**
  - 列表栏宽 380（侧栏显示时 340），行高 62；详情内容最大宽 540、居中。
  - 顶栏行 y=24–78，大标题行 y=86。
  - 侧栏宽 300。
- **Mac：**
  - 侧栏行高 28；列表栏宽 316；详情卡片圆角 12；表单行最小高 38。
  - 窗口圆角 26，靠近窗口角落的控件用同心圆角：按钮圆角 + 内缩 = 26。
- **Token 落地：** 写入 `Sources/DesignSystem/Tokens.swift`。现有的 `Spacing`、`Radius` 可以复用：iPhone 卡片 26 已有 `iPhoneCard`，iPad 18，Mac 12。

## 4. iPhone 页面

每个小节标出画板文件和要改的 Swift 文件。

### 4.1 保险库首页 · `Main.dc.html` → `VaultListView.swift`
- **顶部：** 大标题“保险库”；右侧依次是搜索按钮（独立玻璃圆钮）和［排序与筛选 | 新建］分组胶囊。没有副标题，不显示条目数和同步时间。
- **类型标签条：** 全部 / 登录 / 验证码 / 银行卡 / 身份 / 安全笔记 / SSH 密钥，带计数，单选，可横向滚动。
- **选“全部”时显示概览：**
  - 置顶：4 列图标网格。
  - 文件夹：分组标题右侧“+”新建，点开提示框输入名称；各文件夹带计数，点进文件夹页。
- **条目列表：**
  - 分组标题是当前筛选名，右侧小字显示排序方式。
  - 行：36pt 圆角方块图标 + 名称 + 副标题（用户名或卡尾号）+ 箭头。
  - “按名称”排序要真的排序（中文用本地化比较）。
- **隐藏的条目分组：** 归档、回收站（带计数），进入“回收站与归档”页。
- **排序菜单：** 名称 / 修改日期 / 类型，单选打勾。

### 4.2 搜索 · `iPhone-Search.dc.html` → `VaultListView.swift`（`VaultSearchView`）
- **顶部：** 搜索框（带清除按钮）+“取消”，标签栏停在保险库。
- **类型筛选：** “按类型查找”标签可单选，再点取消选择。
- **结果：** 结果数作为分组标题，点结果打开条目详情。无结果时显示“没有结果”，并说明没有名称、用户名或网站包含输入的内容。

### 4.3 条目详情 · `iPhone-Item.dc.html` → `ItemDetailView.swift`
- **顶栏：** 返回 |［编辑］［置顶 ☆ | 更多 …］。“更多”是排在最右的按钮。
- **头部：** 64pt 图标、名称、“类型 · 修改日期”。
- **字段分组：**
  - 用户名：整行拷贝。
  - 密码：整行拷贝，带眼睛按钮。
  - 验证码：大号等宽字，底部进度条，整行拷贝。
- **链接分组：** 网站（外链）、通行密钥（单行，只读）。
- **其他：** 备注。“更多”菜单：拷贝网址、归档、移到回收站。
- **编辑：** 在本页原地编辑，不跳到新建页。
  - 顶栏变为“取消”和强调色对勾（完成）。
  - 字段变输入框；密码旁有“生成新密码”；文件夹可选；底部是“移到回收站”。

### 4.4 新建条目 · `iPhone-NewItem.dc.html` → `ItemEditView.swift`
- **Sheet 顶部：** 关闭（玻璃 ✕）/ 新建{类型} / 对勾（强调色；名称为空时停用）。
- **类型选择：** 一排 5 个图标按钮：登录、银行卡、身份、安全笔记、SSH 密钥。
- **表单初始状态：** 空表单，不预填。
- **各类型字段：**
  - 通用：名称、文件夹。
  - 登录：用户名、密码（带生成按钮和强度条）、验证码密钥、网站（可增删多条）。
  - 银行卡：持卡人、卡号、有效期（选择器）、安全码。
  - 身份 / 笔记 / SSH 密钥：各自字段，见画板。
  - 通用：置顶开关、备注。

### 4.5 验证码 · `iPhone-Codes.dc.html` → `CodesView.swift`
- **顶部：** 大标题“验证码”+ 右侧“新建”（新建带验证码的登录项）。
- **列表行：** 图标、名称、账户、30pt 等宽验证码，整行拷贝，底部进度条。

### 4.6 Send · `iPhone-Send.dc.html` + `iPhone-SendNew.dc.html` → `OpenVaultSendView.swift`（替换占位）
- **列表页：**
  - 大标题“Send”+ 新建；筛选：全部 / 文本 / 文件。
  - 行：图标、名称、“N 天后删除 · 已访问 x/y 次”、徽章（有密码 / 已过期）、行尾圆形“拷贝链接”按钮。
- **详情（中等高度 Sheet，点行打开）：**
  - 顶部：✕ / 名称 / 编辑。
  - 链接：整行拷贝。
  - 信息：删除时间、过期时间、访问次数、访问密码。
  - 按钮：共享…（`ShareLink`）、删除（先确认）。
- **新建 Send（Sheet）：**
  - 类型：文本 / 文件。
  - 内容：名称；文本 + “默认隐藏文本”，或文件 + 选择文件。
  - 有效期：删除时间（1 小时 / 1、2、3、7、30 天）、过期时间（不过期 / 1 小时 / 1 天 / 7 天）。
  - 访问：最大访问次数、访问密码、隐藏我的邮箱。
  - 对勾：创建并拷贝链接。

### 4.7 回收站与归档 · `iPhone-Trash.dc.html` → 新建 `TrashView.swift`
- **顶栏：** 返回 |“清空”。点“清空”从按钮弹出确认：“永久删除 N 个条目”/“取消”。
- **回收站列表：**
  - 左滑出现“恢复”和“删除”。
  - 恢复后底部提示；删除先弹确认框。
  - 列表为空时显示“回收站是空的”。
- **归档分组：** 行尾“取消归档”，没有条目时显示“没有归档的条目”。

### 4.8 文件夹 · `iPhone-Folder.dc.html` / `iPhone-Folders.dc.html` → 新建
- **文件夹内容页：**
  - 顶栏：返回 |［文件夹操作 … | 在此文件夹新建］。
  - 操作菜单：重命名（提示框输入）、删除。删除确认文案：其中 N 个条目移到“无文件夹”。
- **设置 › 文件夹：** 左滑可重命名或删除；右上 + 新建。

### 4.9 设置 · `iPhone-Settings.dc.html` → `SettingsView.swift`
设置是标签页（从头像进入），大标题“设置”，不再有“完成”按钮。
- **账户卡：** 头像、姓名、邮箱、服务器。下面一行是同步状态（“已同步 · 2 分钟前 / 正在同步…”）和“立即同步”。
- **安全：** 面容 ID 解锁、自动锁定（立即 / 1、5、15 分钟后 / 1 小时后）、清空剪贴板（30 秒 / 1 / 2 分钟 / 永不）。
- **自动填充：** “密码与通行密钥填充”，点按打开系统设置。
- **外观：** 跟随系统 / 浅色 / 深色。
- **保险库：** 文件夹、导入与导出（进入子页）。
- **账户操作：** 立即锁定；退出登录（先确认）。
- **版本号：** 放在页面底部。

### 4.10 导入与导出 · `iPhone-ImportExport.dc.html` → 新建
- **切换：** 分段控件，导入 / 导出。
- **导入：**
  - 来源：Bitwarden JSON / Apple 密码 CSV / Chrome·Edge CSV / 1Password 1PUX。
  - 放入文件夹。
  - 来源说明：该来源包含哪些字段。
  - 按钮：“选择文件并导入…”。
- **导出：**
  - 格式：JSON / 加密 JSON / CSV；选加密 JSON 时有文件密码。
  - 主密码确认。
  - 格式说明（含未加密警告），以及“附件、Send 和回收站中的条目不会导出。”
  - 按钮：“导出…”，保存到“文件”。

### 4.11 生成器 · `iPhone-Generator.dc.html` → `GeneratorView.swift`
- **顶部：** 大标题“生成器”+ 历史按钮。
- **生成类型：** 分段控件，密码 / 密码短语 / 用户名。
- **结果卡片：** 大号等宽字，数字蓝色、符号橙色；强度条四段，并显示等级。
- **按钮：** 重新生成（填充色按钮）、拷贝（强调色；拷贝后显示“已拷贝”）。
- **选项：**
  - 密码：长度滑块 8–64，大写、小写、数字、符号开关。
  - 短语：单词数步进器、分隔符、首字母大写、包含数字。
  - 用户名：基础名称、域名、随机后缀位数。
- **生成历史（Sheet）：**
  - 顶部“清除”和“完成”。
  - 点按某条即拷贝。
  - 没有历史时显示空状态。

### 4.12 登录 · `iPhone-Login.dc.html` → `LoginView.swift`、`TwoFactorView.swift`、`UIShared/LoginModel.swift`
**第一页：账户与主密码，一页填完。** 整组在可用区域内居中、略偏上，按钮不钉在屏幕底部。
- 64pt 图标 + 大标题“登录 OpenVault”。
- **服务器胶囊（标题下方）：** 显示主机名。点开菜单列出最近用过的服务器（勾选当前）和“其他服务器…”；选“其他服务器…”弹出带输入框的提示框（取消 / 使用）。
- **输入分组：** 邮箱、主密码两行；左侧是标签，主密码一行带显示/隐藏按钮。
- **登录按钮：** 紧跟在分组下方。邮箱格式正确且主密码非空才可点，加载时显示“正在登录…”。
- **“获取主密码提示”：** 普通文字按钮；发送后变为“提示已发送到 …”。
- **登录逻辑：** 提交时先调用 `prelogin(email:)` 拿 KDF 参数，再派生密钥并请求 token。邮箱和主密码不再分两页。

**第二页：两步验证（服务器要求时才出现）。**
- 返回按钮；标题“两步验证”和说明。
- 验证器 / 邮件切换；6 格验证码（`.oneTimeCode`）；记住这台 iPhone。
- “验证”按钮：6 位填满才可点。邮件方式时显示“重新发送邮件”。

### 4.13 解锁 · `iPhone-Unlock.dc.html` → `UnlockView.swift`
- **中部：** 图标 + “保险库已锁定” + 邮箱，不显示服务器地址和自动锁定时间。
- **底部：** “使用面容 ID 解锁”（主按钮）和“使用主密码”。切换到主密码后是密码框 + “解锁”（有输入才可点）+ “使用面容 ID”。
- **右上：** “…”菜单：退出登录。

### 4.14 自动填充 · `iPhone-AutoFill.dc.html` → `App/AutoFill/ExtensionViews.swift`
- **浮动 Sheet 顶部：** OpenVault 标识、“选择用于 {域名} 的凭据”、关闭按钮。
- **凭据行：** 名称加粗 + 副标题，最近使用的一项带徽章；通行密钥单独一行。
- **其他：** 最后一行是“搜索其他凭据”。选中一项后填充并关闭。

## 5. iPad 页面（与 iPhone 共用模型与大部分视图）

### 5.1 保险库 · `iPad-Vault.dc.html`
- **列表栏工具栏（顶栏行右端）：** 搜索 +［排序 | 新建］。
- **列表栏：**
  - 大标题随筛选变化（保险库 / 置顶 / 登录 / 工作 / 归档 / 回收站…）。
  - 侧栏隐藏时显示类型标签条（放不下就换行）。
  - 行高 62，选中行浅强调色底，置顶条目带橙色星标。
- **详情栏：**
  - 工具栏：［编辑］［置顶 | 更多］。内容最大宽 540、居中。
  - 字段规则与 iPhone 相同，各类型的字段见画板。
  - 编辑：原地编辑，工具栏变“取消”和强调色对勾。
  - “更多”菜单：克隆、移到文件夹（二级菜单，单选打勾）、归档、移到回收站。
  - 回收站中的条目：工具栏为“恢复”和“永久删除”（先确认）。归档条目：“取消归档”和“移到回收站”。
  - 移到回收站或归档后，底部提示带“撤销”。
- **侧栏“文件夹 +”：** 弹出提示框新建，建好后选中这个文件夹。
- **空状态：** 回收站、归档、普通筛选各有一句话。

### 5.2 其他 iPad 页面
- **验证码 · `iPad-Codes.dc.html`：** 卡片网格（侧栏隐藏时 4 列，显示时 3 列），卡片整块点按拷贝，底部进度条。
- **搜索 · `iPad-Search.dc.html`：** 搜索框在顶栏中间 + 关闭；下面是类型筛选和结果。
- **Send · `iPad-Send.dc.html`：**
  - 列表栏 + 详情栏；详情工具栏：［编辑］［共享 | 更多］。
  - 共享菜单：拷贝链接、通过“信息”发送、通过邮件发送、存储到“文件”。
  - 更多菜单：移除访问密码、停用 / 重新启用、删除（先确认）。
  - 新建和编辑都用居中表单页。
- **生成器 · `iPad-Generator.dc.html`：** 两栏布局，左栏是结果和操作，右栏是选项；历史从按钮弹出浮层。
- **新建条目 · `iPad-NewItem.dc.html`：** 居中表单页（`.presentationSizing(.form)`），内容同 iPhone。
- **设置 · `iPad-Settings.dc.html`：**
  - 标签页：左栏分类，右栏内容。
  - 分类：账户、安全、自动填充、外观、文件夹、导入与导出、关于。
  - “锁定后的操作”选“退出登录”时显示一句后果说明。
- **登录 / 解锁：** 内容同 iPhone，放在居中的 420 / 400 宽内容列里。

## 6. Mac 页面

### 6.1 登录窗口 · `Mac-Login.dc.html` → `MacLoginView.swift`、`MacRootView.swift`
- **窗口：** 独立窗口 560×500，缩放按钮置灰。
- **第一步（账户与主密码）：**
  - 图标 64 + “登录 OpenVault”。
  - 三个系统大号输入框，框内不放图标：邮箱、服务器（组合框，下拉列出最近使用的服务器和“使用其他服务器…”，用 `TextField.textInputSuggestions`）、主密码（带显示/隐藏）。
  - 右下“获取主密码提示”。
- **两步验证：** 说明、验证器 / 邮件切换、6 格验证码、记住这台 Mac、重新发送；不再用 390 宽的 Sheet。
- **按钮：**
  - 默认按钮在右下角，响应回车：第一步是“登录”，就绪前是普通按钮；两步验证时是“验证”。
  - “返回”在它左边，只在两步验证时出现。
  - 帮助按钮（?）在左下角，点开浮层说明。

### 6.2 主窗口
- **解锁 · `Mac-Unlock.dc.html` → `MacUnlockView.swift`：**
  - 主窗口的锁定状态：App 图标带锁标记、“OpenVault 已锁定”、邮箱。
  - 触控 ID 按钮是唯一着色的主要操作，等待时显示“请将手指放在触控 ID 上”。
  - 下面是“或输入主密码”分隔线，主密码框右侧带解锁箭头。
  - 底部只放“退出登录…”。
- **保险库 · `Mac-Vault.dc.html` → `MacMainView`、`MacItemListView`、`MacItemDetailView`：**
  - 工具栏：
    - 左侧：标题 +［立即同步 | 新建］。同步时标题下显示“正在同步… / 已同步”，2 秒后消失，平时不显示。
    - 右侧：［编辑 | 归档 | 移到回收站 | 信息］+ 搜索框（⌘K）。
  - 详情：
    - 头部：图标、标题（26 Bold）、置顶星标、副标题。
    - 字段卡片：每行整行点按拷贝，值右侧显示“已拷贝”。
    - 密码：悬停或获得焦点时显示明文。
    - 验证码行：底部进度条。
    - 网站卡片（外链）、备注卡片，底部是创建 / 修改信息。
  - “信息”按钮：打开浮层，显示条目元数据。
  - 归档、移到回收站后的底部提示带“撤销”。
- **验证码 · `Mac-Codes.dc.html` → `MacAuthenticatorViews.swift`：**
  - 列表栏顶部显示“N 个账户”，可筛选；没有匹配时显示提示。
  - 详情是大号验证码卡片，整块点按拷贝，带进度条。
- **生成器 · `Mac-Generator.dc.html` → `MacToolViews.swift`（`MacGeneratorView`）：** 结果、选项；右侧可切换历史侧栏，点按某条即拷贝。
- **新建 / 编辑条目 · `Mac-Edit.dc.html` → `MacItemEditView.swift`：**
  - 用 Sheet。
  - 底部按钮：右下“存储”（默认按钮），它左边是“取消”。
  - 密码旁有“生成”。
- **Send · `Mac-Send.dc.html`、`Mac-SendNew.dc.html` → `MacSendView`（替换占位）：**
  - 列表 + 详情；工具栏：新建、［编辑 | 删除］。
  - 新建 Send 用 600×600 的 Sheet，字段同 iPhone，按钮是“取消”和“创建并拷贝链接”。
- **归档与回收站 · `Mac-Trash.dc.html`：**
  - 详情顶部的状态条写“此条目在回收站中 / 此条目已归档”。
  - 回收站条目：“永久删除…”和“恢复”（默认按钮）。归档条目：“取消归档”。
  - 列表栏顶部的“清空回收站…”和永久删除都要先确认。
- **导入 / 导出 · `Mac-Import.dc.html`（560×340）、`Mac-Export.dc.html`（560×500）：**
  - 都用 Sheet。
  - 导入：来源选择、文件选择、放入文件夹。
  - 导出：格式、文件密码、主密码确认，并带未加密警告。
- **设置 · `Mac-Settings.dc.html` → `MacSettingsView.swift`，拆成面板：**
  - 通用：在菜单栏中显示、清除剪贴板。
  - 账户：头像、邮箱、服务器、KDF、退出登录…
  - 安全：触控 ID、自动锁定（含“睡眠时”）、睡眠或锁屏时立即锁定。
  - 同步：同步状态。
  - 自动填充：“打开系统设置…”，下面一句说明在哪里选择 OpenVault。
- **菜单栏面板 · `Mac-MenuBar.dc.html` → `MenuBarContent.swift`：**
  - 顶部状态“已解锁”，下面是搜索和“最近使用”列表。
  - 选中一行后显示“拷贝用户名 / 密码 / 验证码”三个小按钮。
  - 底部：生成并拷贝密码（⌥⌘G）、打开 OpenVault、锁定保险库（⇧⌘L）。

## 7. 数据与接口改动

| 项目 | 现状 | 要做的改动 |
|---|---|---|
| 登录流程 | 邮箱、主密码分两页 | 一页提交：先 `prelogin` 拿 KDF 参数，再派生密钥、请求 token；需要两步验证时进入第二页 |
| 删除条目 | `DELETE /api/ciphers/{id}`，直接永久删除；本地有 `deletedDate`，但列表把这些条目过滤掉了 | “移到回收站”改用 `PUT /api/ciphers/{id}/delete`；“恢复”用 `PUT /api/ciphers/{id}/restore`；只有“永久删除”和“清空”用 `DELETE`。列表显示回收站中的条目 |
| 归档 | 不支持 | 需要 Vaultwarden 1.36.0 及以上：同步归档日期字段，接归档和取消归档请求；列表、搜索、自动填充都排除已归档条目 |
| 文件夹 | 同步时会拉取，`APIClient` 已有 create / update / delete，但没有界面 | 仓库层接上增删改（名称要加密）；列表按 `folderID` 筛选；删除文件夹后其中条目归入“无文件夹”；编辑页可选文件夹 |
| Send | 只有占位页和 `SendType` 枚举 | 同步时读取 sends；接 `/api/sends` 的新建、修改、删除、移除密码，文件 Send 用 `/api/sends/file/v2`；在本机生成 Send 密钥并加密内容；链接格式为“服务器/#/send/访问 ID/密钥” |
| 导入 / 导出 | 不支持 | 导入：解析各来源格式，在本机加密后批量创建，重复条目不合并。导出：先校验主密码；JSON / CSV 不加密；加密 JSON 用文件密码派生密钥，格式与 Bitwarden 兼容 |
| 置顶 | 已有 favorite 字段 | 置顶切换直接调用更新接口 |
| 生成历史 | 无 | 只存在本机 Keychain 或加密存储，最多 100 条，不同步 |

另见第 10 节“功能对照”表。

## 8. 实现顺序与验收

1. **Token 与基础组件。**
   - `Tokens.swift` 对齐第 3 节。
   - 拷贝行组件（行内“已拷贝”）、验证码进度条、Mac 悬停显示密码、底部操作结果提示（带撤销）。
   - 验收：增强对比度下文字对比度达标（第 9 节），深色模式正常。
2. **导航骨架。**
   - iPhone、iPad 共用 `TabView`：四个标签 + 头像入口、侧栏可切换、搜索放在保险库工具栏。
   - Mac `NavigationSplitView` 侧栏分组。
   - 删除 `OpenVaultPadWorkspace` 分支。
   - 验收：每个入口都能到达对应画板描述的页面。
3. **保险库列表与详情**（三端），包括排序、类型 / 文件夹筛选、置顶、原地编辑。
4. **登录 / 解锁**（三端），登录合并为一页。
5. **回收站与归档**（接口改动 + 三端界面）。
6. **文件夹管理。**
7. **Send**（模型、加密、接口、三端界面）。
8. **生成器与历史、设置**：iPhone 和 iPad 是标签页，Mac 用 Settings 场景。
9. **导入 / 导出。**
10. **菜单栏面板、自动填充扩展。**
11. **收尾。**
    - 按第 9 节“必须测试的系统设置”逐项检查：增强对比度、降低透明度、深色、大字体、减少动态效果、VoiceOver。
    - 补 `Tests/Interface` 的 UI 测试，覆盖登录、拷贝、移到回收站并撤销、Send 新建。

每完成一项，在提交说明里注明对应画板文件。不确定时以画板行为为准；画板和本文件冲突时以本文件为准。

## 9. 设计规范（来自“设计规范”画板）
### 9.1 Liquid Glass 使用规则

1. **玻璃只放在导航与控件层** 标签栏、工具栏、侧栏、Sheet、拷贝提示用玻璃；列表、卡片、内容里的按钮一律不透明。
2. **不叠玻璃** 侧栏和菜单栏面板本身已是材质，里面的按钮和搜索框改为无边框或普通填充。
3. **优先系统组件，去掉自定义背景** 工具栏、标签栏、分栏不加自定义底色；内容滚到栏下时交给系统的 scroll edge effect。
4. **只用系统色** 不设自定义强调色；所有文字、背景、分隔线、状态色都用系统语义色，自动适配深色与高对比度。
5. **颜色只给唯一的主要操作** 只有“完成 / 存储”用强调色玻璃；置顶星标等状态图标保持单色。
6. **工具栏分组 ≤ 3** 按功能分组；文字按钮“编辑”单独成组；图标按钮都有无障碍标签；不加圆圈边框的符号。
7. **标签栏只做导航** 实心图标 + 单词标签；搜索用 role: .search 自动放尾端；进入详情页不隐藏标签栏。
8. **iPad 用可切换侧栏的标签栏** 默认在顶部显示标签栏，左上按钮可切换为侧栏；“类型”分组只在侧栏模式出现。
9. **搜索按平台放置** iPhone、iPad 都是搜索标签（标签栏尾端）；Mac 放工具栏尾端。
10. **侧栏图标用强调色** 默认跟随强调色（Mac 跟随系统强调色设置），只有“置顶”固定为系统橙。Mac 侧栏底部不放关键信息。
11. **同心圆角** Mac 窗口 26pt，侧栏内缩 8pt 后为 18pt；控件统一胶囊形。
12. **不重复系统设置** 外观（浅色 / 深色）跟随系统，不在 App 里再做主题开关。
13. **Mac 设置与菜单栏** 设置放在 App 菜单（⌘,）打开的独立窗口，标题随面板变化，最小化和缩放按钮置灰；菜单栏图标由用户在设置里决定是否显示。
14. **滑动操作与菜单首项一致** 列表左滑“拷贝密码”、右滑“删除”，长按菜单前两项也按这个顺序。
15. **增强对比度下逐项达标** 蓝色文字只放在白色卡片或玻璃上；深色高对比时强调色底上的文字改黑色。
16. **Mac 用 macOS 字号** 正文和侧栏 13pt，分组标题与脚注 11pt，窗口标题 15pt，详情标题 22pt；不沿用 iOS 的 17pt。

### 9.2 系统色（浅色 / 深色）

| 名称 | SwiftUI | 浅色 | 深色 |
|---|---|---|---|
| 蓝 · 强调色 | `.blue` | #0088FF | #0091FF |
| 红 | `.red` | #FF383C | #FF4245 |
| 橙 | `.orange` | #FF8D28 | #FF9230 |
| 绿 | `.green` | #34C759 | #30D158 |
| 靛 | `.indigo` | #6155F5 | #6D7CFF |
| 粉 | `.pink` | #FF2D55 | #FF375F |
| 紫 | `.purple` | #CB30E0 | #DB34F2 |
| 青 | `.cyan` | #00C0E8 | #3CD3FE |

### 9.3 颜色语义（一色一义）

| 用途 | 规则 |
|---|---|
| 强调色 | 默认 .tint（系统蓝），不建 AccentColor |
| 页面底色 | Color(.systemGroupedBackground) |
| 分组 / 卡片 | Color(.secondarySystemGroupedBackground) |
| 主文字 | .primary |
| 次文字 | .secondary |
| 占位文字 | Color(.placeholderText) |
| 分隔线 | Color(.separator) |
| 胶囊 / 分段底 | Color(.tertiarySystemFill) |
| 危险 / 警示 / 成功 | .red / .orange / .green |
| 生成器数字 / 符号 | .indigo / .pink |
| Mac 列表选中 | Color(nsColor: .selectedContentBackgroundColor) |

### 9.4 增强对比度：对比度检查（默认 → 增强对比度）

| 组合 | 默认 | 增强对比度 | 结论 | 备注 |
|---|---|---|---|---|
| 次要文字 · 白色卡片 | 3.44 | 5.23 | 达标 |  |
| 次要文字 · 分组底（分区脚注） | 3.30 | 4.69 | 达标 |  |
| 系统蓝 · 白色卡片 | 3.52 | 4.57 | 达标 | 链接、文字按钮只放在卡片或玻璃上 |
| 系统蓝 · 分组底 | 3.15 | 4.10 | 已处理 | 不在分组底上放蓝色文字按钮 |
| 系统蓝 · Mac 窗口底 | 3.41 | 4.42 | 已处理 | Mac 蓝色文字只放在表单分组里 |
| 白字 · 系统蓝（主要按钮） | 3.52 | 4.57 | 达标 |  |
| 系统红 · 白底（删除） | 3.57 | 4.56 | 达标 |  |
| 系统橙 · 白底（将过期） | 2.31 | 4.55 | 达标 | 默认下同时显示秒数和圆环 |
| 系统绿 · 白底（强度高） | 2.22 | 4.54 | 达标 | 同时显示“强”字 |
| 系统粉 · 白底（符号） | 3.65 | 4.57 | 达标 |  |
| 深色 · 次要文字 · 卡片 | 5.95 | 7.69 | 达标 |  |
| 深色 · 系统蓝 · 卡片 | 5.26 | 7.90 | 达标 |  |
| 深色 · 白字 · 系统蓝 | 3.23 | 2.15 | 已处理 | 高对比时改黑字，9.76:1 |
| 系统蓝 · 灰色填充按钮 | 3.05 | 3.59 | 待复查 | iOS 系统 .bordered 控件，真机复查；Mac 按钮文字已改为主文字色 |

### 9.5 必须测试的系统设置

| 设置 | 期望 |
|---|---|
| 增强对比度 | 各画板 Tweaks 可预览。系统色切到高对比版本，玻璃加描边；逐项结果见“增强对比度”一节 |
| 降低透明度 | 玻璃变为不透明底，标签栏与 Toast 文字仍清晰 |
| Liquid Glass 外观（清透 ↔ 着色） | 两端都检查标签栏、Toast 文字是否清晰 |
| 减弱动态效果 | 去掉玻璃形变；倒计时环改为逐秒跳变 |
| 动态字体 AX1–AX5 | 验证码行改为两行，列表副标题不截断关键字段 |

## 10. 对照表

### 10.1 实现对照：设计 → SwiftUI

| 元素 | 设计 | SwiftUI / API | 代码改动 |
|---|---|---|---|
| iPhone 标签栏 | 左侧一组四个标签（保险库 / 验证码 / Send / 生成器），实心图标，滚动时收起；右侧单独一个圆形玻璃按钮显示账户头像，进入设置，当前在设置页时头像带强调色描边；只有保险库需要搜索，搜索按钮和排序、新建一起放在“保险库”大标题同一行的右侧 | TabView { Tab(…) ×4 ; Tab(value: .account, role: .search) { SettingsView() } label: { 头像 } }  .tabBarMinimizeBehavior(.onScrollDown)；系统只会把 role: .search 的标签单独做成圆形，这里借用它放头像，需设置无障碍标签“账户与设置”，且设置页内不加 .searchable；保险库页 .searchable(text:, isPresented:) 由工具栏按钮唤起 | MainTabView：“发送”改名 Send，接入真实列表；账户头像从各页工具栏移到标签栏右侧的独立位；图标用 .fill 变体 |
| iPad 标签栏 | 顶部标签栏（保险库 / 验证码 / Send / 生成器）右侧是账户头像按钮，可切换为侧栏；“类型”“文件夹”“隐藏的条目”分组只在侧栏出现 | TabView { …; TabSection("类型") { … } }  .tabViewStyle(.sidebarAdaptable)；搜索按钮在保险库列表栏工具栏 | MainTabView：删掉 regular 宽度走 OpenVaultPadWorkspace 的分支，iPhone 与 iPad 共用同一个 TabView |
| iPad 侧栏 | 左上角按钮把标签栏切换为悬浮玻璃侧栏（内缩 10pt、圆角 18pt）；内容区随之右移，不被遮挡；侧栏底部是账户行（头像、姓名、邮箱），进入设置 | TabView(selection:) { … }.tabViewStyle(.sidebarAdaptable)；TabSection 的 sectionActions 放“新建文件夹”；.defaultAdaptableTabBarPlacement(.tabBar) | 侧栏中的类型、文件夹、归档、回收站都只是保险库列表的筛选，不另开页面 |
| iPad 表单页 | 新建条目、新建 Send 用居中表单页：左上关闭（玻璃）、右上对勾（强调色）；设置是标签页，左栏分类、右栏内容 | .sheet { … }.presentationSizing(.form)；工具栏 ToolbarItem(placement: .cancellationAction / .confirmationAction) | 完成按钮在必填项为空时停用 |
| iPad 菜单与确认 | 排序、更多、共享用工具栏里的玻璃菜单；永久删除、退出登录用居中提示框，破坏性按钮为红色 | Menu { Picker(…) ; Button(role: .destructive) }；.alert(…) { Button("删除", role: .destructive) } | 移到回收站、归档给出可撤销的底部提示；永久删除没有撤销，只能用确认框 |
| 说明文字 | 不写重复界面已表达的内容：不解释手势（轻点拷贝、左滑）、不重复安全承诺（本机加密、派生密钥）、不显示服务器地址和自动锁定时间；只保留确认框里的后果说明、空状态和会影响选择的限制（如导出未加密） | Section footer 只在必要时使用；.alert message 写清后果 | 删掉各页面 footer 里的说明句，空出的间距由分组间距自然收拢 |
| 详情页 | 保留标签栏，不再隐藏 | 不要对详情使用 .toolbar(.hidden, for: .tabBar) | ItemDetailView |
| 工具栏按钮 | 按功能分组，最多 3 组；“编辑”单独一组 | ToolbarItemGroup · ToolbarSpacer(.fixed) · .accessibilityLabel | VaultListView、ItemDetailView |
| 主要操作 | “完成 / 存储”唯一着色 | ToolbarItem(placement: .confirmationAction) · .buttonStyle(.glassProminent) | ItemEditView、SettingsView（Sheet） |
| 颜色 | 全部系统语义色，强调色 = 系统蓝 | Color(.label) / .secondary / Color(.systemGroupedBackground) …；不设 AccentColor | Tokens.swift 的 Palette 已基本是系统色，保持；去掉其他写死的 RGB |
| 标题 | 大标题 + 同步状态副标题 | .navigationTitle(…)  .navigationSubtitle(…) | 替代首页 4 个统计磁贴 |
| 列表 | 系统分组列表；滑动与菜单动作一致；Mac 列表选中由系统绘制：列表有焦点时为强调色底、主文字变白，失去焦点时变灰；自定义图标块保持原色 | List { Section }  .listStyle(.insetGrouped)  .swipeActions  .contextMenu | 删掉 ScrollView + OpenVaultCard + VaultRowsCard |
| 内容层按钮 | 登录、解锁、拷贝等用不透明按钮 | .buttonStyle(.borderedProminent / .bordered)  .controlSize(.extraLarge) | UnlockView 现在用 .vaultProminentButtonStyle(glass: true)，改为不透明样式；LoginView、GeneratorView 同理 |
| Sheet | 设置、新建、自动填充；中号自动内缩 | .sheet  .presentationDetents([.medium, .large])，不设 .presentationBackground | 设置从 push 改为 Sheet |
| 确认操作 | 退出登录、删除从触发按钮弹出 | .confirmationDialog(…)，锚定在触发按钮上 | SettingsView、ItemDetailView |
| 拷贝反馈 | 点按用户名、密码、验证码直接拷贝，在被点的那一行就地显示“已拷贝”1.6 秒；只有恢复、删除这类操作结果才用底部玻璃提示（唯一的自定义玻璃元素） | 行内：withAnimation { copiedField = .password }，1.6 秒后清空；底部提示：.glassEffect(.regular, in: .capsule) | GlassToast / copyToast 只留给操作结果；拷贝改为行内反馈 |
| Mac 侧栏 | 系统侧栏，macOS 27 自动成为悬浮的 Liquid Glass 面板（内缩 8pt、圆角 18pt、透出桌面和内容的颜色）；行文字 13pt，分组标题 11pt；焦点在列表时侧栏选中为灰色；图标用强调色，仅置顶为系统橙 | NavigationSplitView { List(selection:) { Section { Label(…).badge(n) } }.listStyle(.sidebar) }；不给侧栏和分栏加 .background 或 NSVisualEffectView | MacSidebarView 已是系统侧栏，保留；删掉 .safeAreaBar(edge: .bottom) { accountFooter }，去掉“安全提醒”“设置”；“发送”改名 Send；加“文件夹”“工具”“隐藏的条目”三个分组；MacMainView 第 196 行的 .background(MacOpenVaultStyle.detail) 也删掉，否则挡住玻璃 |
| iPhone / iPad 登录 | 一页填完：标题下方是服务器胶囊（显示主机名，点开菜单选最近用过的或“其他服务器…”），下面一个分组放邮箱和主密码，紧跟“登录”按钮和“获取主密码提示”；整组在可用区域内居中、略偏上，按钮不钉在屏幕底部；只有服务器要求时才进入第二页两步验证 | Form { TextField("邮箱").textContentType(.username) ; SecureField("主密码").textContentType(.password) } ; Menu { Picker(…) ; Button("其他服务器…") } ; .alert("其他服务器") { TextField(…) } | LoginView 合并邮箱和主密码两步；提交时先请求 prelogin 拿 KDF 参数，再派生密钥登录 |
| Mac 登录 | 独立的紧凑窗口（560×500，固定尺寸，缩放按钮置灰）：邮箱、服务器、主密码在同一页填完（登录时先请求 prelogin 拿 KDF 参数再派生密钥），服务器需要时才进入第二步两步验证；输入框用系统大号尺寸，框内不放图标；按钮按 macOS 惯例放在右下角——默认按钮（继续 / 登录 / 验证）在最右，响应回车，“返回”在它左边，帮助在左下角；邮箱和服务器是两个独立的系统输入框，用占位文字说明；服务器是组合框：可以直接输入网址，右侧箭头列出最近用过的服务器并勾选当前那个，最后一项“使用其他服务器…”清空输入框以便填写新地址；首次启动时输入框为空，只显示示例地址；聚焦环只在真正获得焦点时出现，且只围住当前输入框；底部按钮与窗口圆角同心（按钮半径 + 边距 = 窗口圆角） | Window("登录", id: "login") .windowResizability(.contentSize) .windowStyle(.hiddenTitleBar)；TextField / SecureField .controlSize(.extraLarge)；TextField("服务器", text: $server).textInputSuggestions { ForEach(recentServers) { Text($0.host).textInputCompletion($0.url) } }；Button("继续").buttonStyle(.borderedProminent).keyboardShortcut(.defaultAction)；HelpLink；.textContentType(.oneTimeCode) | MacRootView 现在把登录放进 1260×780 的主窗口；MacLoginView 合并为“账户与主密码”和“两步验证”两步；两步验证不再用 390 宽的 Sheet |
| Mac 解锁 | 主窗口锁定态：App 图标带锁标记；触控 ID 是唯一着色的主要操作，等待时显示提示；主密码输入框右侧带解锁箭头；底部只留“退出登录…” | LAContext().evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, …)；SecureField(…).onSubmit { unlock() } | MacUnlockView |
| Mac 详情 | 标题 26pt，副标题为网站或类型；字段用分组表单，标签在左、值在右；用户名、密码、验证码整行可点，点按直接拷贝，行尾显示“已拷贝”1.6 秒，不弹菜单也不弹提示；悬停或键盘聚焦时整行变浅灰，密码淡入显示（数字和符号分色）；验证码这一行的底边是一条随时间缩短的进度条，最后 5 秒变橙色；网站用系统链接；文件夹和修改时间放在最下面一行 | Button { copy(value) } label: { LabeledContent("密码") { … } }.buttonStyle(.plain).contentShape(.rect)；.onHover { isHovering = $0 }；TimelineView(.periodic(from: .now, by: 1)) { ProgressView(value: remaining, total: 30) }；Link(destination:)；Send 的共享用 ShareLink(item: url) | MacItemDetailView：去掉每行的拷贝按钮和 OpenVaultCard；删掉 .background(MacOpenVaultStyle.detail) 和底部安全说明 |
| Mac 设置窗口 | 独立窗口，工具栏面板：通用 / 账户 / 安全 / 同步 / 自动填充 | Settings { TabView { … .tabItem { Label(…) } } }（系统自动提供 ⌘,） | TesseraMacApp 新增 Settings 场景；MacSettingsView 拆成面板 |
| 菜单栏图标 | 保留窗口样式（有搜索，菜单装不下）；由用户决定是否显示 | MenuBarExtra(…, isInserted: $showInMenuBar)  .menuBarExtraStyle(.window) | TesseraMacApp；“通用”面板加开关 |
| 增强对比度 | 系统色自动切换；深色高对比时强调色底上的文字改黑色；Mac 选中行用系统选中色 | @Environment(\.colorSchemeContrast) · Color(nsColor: .selectedContentBackgroundColor) | 自绘的彩色图标底块、头像、类型选择器、复选框 |
| 外观 | 跟随系统，不提供主题开关 | 去掉 .preferredColorScheme(…) | Tokens.swift 的 OpenVaultTheme 与两端设置页的“主题” |
| 搜索 | iPhone / iPad 搜索标签；Mac 工具栏尾端 | Tab(role: .search) · .searchable(text:prompt:) | VaultSearchView、MacMainView（⌘K 保留） |
| Mac 命令 | 每个工具栏按钮都有菜单命令和快捷键；“文件”菜单放新建条目、新建文件夹、新建 Send、导入、导出 | .commands { CommandGroup(replacing: .newItem) { … } ; CommandMenu("保险库") { … } }  .keyboardShortcut(…) | TesseraMacApp：现在只有“锁定”，补新建条目（⌘N）、新建文件夹（⇧⌘N）、新建 Send、导入…、导出…、同步、编辑、移到回收站、条目信息，以及拷贝用户名（⇧⌘U）、拷贝密码（⇧⌘C）、拷贝验证码（⌥⌘C） |
| 文件夹 | Mac 侧栏分组，标题右侧“+”新建、右键重命名或删除；iPhone 首页分组；编辑页选文件夹 | Section { ForEach(folders) { Label(name, systemImage: "folder").contextMenu { … } } } header: { … }；Picker("文件夹", selection: $folderID) | VaultRepository 接上 APIClient 已有的 createFolder / updateFolder / deleteFolder；两端编辑页的 folderID 改为可选择 |
| Send | Mac 侧栏“工具”里的 Send：列表 + 详情 + 新建表单；iPhone 新增 Send 标签 | ShareLink(item: url) · .confirmationDialog · DatePicker（自定义删除时间） | MacSendView 占位页换成真实列表；新建 Send 的仓库层与加密 |
| 回收站与归档 | 删除先进回收站，可恢复；永久删除和清空要确认；归档不进列表、搜索和自动填充 | .swipeActions { Button("恢复") ; Button("删除", role: .destructive) } · .alert(…) { Button(role: .destructive) } | VaultRepository.deleteCipher 改为移到回收站，新增恢复和永久删除；VaultStore 读取 deleted_date 非空的行 |
| 导入与导出 | Mac 用“文件”菜单打开表单；iPhone 在设置“保险库”里 | .fileImporter(…) · .fileExporter(…) | 新增导入解析与导出模块 |

### 10.2 功能对照：Bitwarden 桌面端 → OpenVault

| 功能 | 状态 | 设计 | 现状 | 要做的改动 |
|---|---|---|---|---|
| 全部条目与类型 | 已有 | 侧栏“类型”：登录、银行卡、身份、安全笔记、SSH 密钥 | 已实现 | — |
| 收藏 | 已有 | “置顶” | 已实现（favorite 字段） | — |
| 文件夹 | 本次补设计 | Mac 侧栏“文件夹”分组，“+”新建，右键重命名或删除；iPhone 首页“文件夹”分组；两端编辑页可选文件夹；iPhone 设置里管理 | 同步时会拉取文件夹，APIClient 已有增删改接口，但没有任何界面；编辑条目时只保留原来的 folderID | 仓库层接上增删改（文件夹名要加密）；列表按 folderID 筛选；删除文件夹后其中条目归入“无文件夹” |
| Send | 本次补设计 | Mac 侧栏“工具 › Send”：列表、详情、新建表单（文本或文件、删除与过期时间、访问次数、访问密码、隐藏邮箱、私人备注）；iPhone 和 iPad 新增 Send 标签 | 只有占位页 MacSendView 和 SendType 枚举，README 写明暂不支持 | 同步结果里读取 sends；接 /api/sends 的新建、修改、删除、移除密码，文件 Send 走 /api/sends/file/v2；在本机生成 Send 密钥并加密内容，链接为“服务器/#/send/访问 ID/密钥” |
| 回收站 | 本次补设计 | Mac 侧栏“隐藏的条目 › 回收站”：恢复、永久删除、清空都要确认；iPhone 左滑恢复或删除 | 删除调用 DELETE /api/ciphers/{id}，直接永久删除；本地存了 deleted_date，但列表把这些行过滤掉了 | 删除改为 PUT /api/ciphers/{id}/delete（移到回收站），恢复用 PUT /api/ciphers/{id}/restore，只有“永久删除”才用 DELETE |
| 归档 | 本次补设计 | Mac 侧栏“隐藏的条目 › 归档”，可取消归档；iPhone 在回收站页下方 | 不支持 | 需要 Vaultwarden 1.36.0 及以上；同步归档日期字段，接归档和取消归档请求；列表、搜索、自动填充都排除已归档条目 |
| 生成器 | 已有 | 密码、口令、用户名 | 已实现 | — |
| 导入 | 本次补设计 | Mac“文件 › 导入…”表单；iPhone“设置 › 导入与导出” | 没有 | 解析 Bitwarden JSON/CSV、Apple 密码、Chrome、1Password；本机加密后批量上传（/api/ciphers/import，带文件夹关系） |
| 导出 | 本次补设计 | Mac“文件 › 导出…”表单：JSON、加密 JSON、CSV，先验证主密码 | 没有 | 在本机解密后写文件；加密 JSON 用文件密码派生密钥，格式与 Bitwarden 兼容；CSV 只含登录和安全笔记 |
| 菜单栏 | 本次补设计 | 系统菜单：文件、编辑、显示、保险库、窗口、帮助；每个工具栏按钮都有对应命令 | 只有“锁定”命令 | 用 .commands 补齐，见下方“Mac 命令” |
| 账户菜单与多账户 | 暂不做 | 单账户：锁定、同步、退出登录放在菜单和设置的“账户”面板 | 只有一个活跃账户 | 多账户切换以后再做 |
| 所有密码库与组织、集合 | 暂不做 | 加入组织后，在侧栏顶部加“密码库”切换 | README 写明不支持组织 | — |
| 附件、自定义字段编辑 | 暂不做 | 详情页显示自定义字段；编辑时原样保留 | README 写明不支持附件；自定义字段只读 | 以后在编辑页加“自定义字段”分组 |

## 11. 画板清单

| 文件 | 标题 | 尺寸 |
|---|---|---|
| `design/boards/Main.dc.html` | iPhone · 保险库 | 402×874 |
| `design/boards/iPhone-Login.dc.html` | iPhone · 登录（账户与主密码 → 两步验证） | 402×874 |
| `design/boards/iPhone-Unlock.dc.html` | iPhone · 解锁 | 402×874 |
| `design/boards/iPhone-Item.dc.html` | iPhone · 条目详情 | 402×874 |
| `design/boards/iPhone-Search.dc.html` | iPhone · 搜索 | 402×874 |
| `design/boards/iPhone-Folder.dc.html` | iPhone · 文件夹 | 402×874 |
| `design/boards/iPhone-Folders.dc.html` | iPhone · 管理文件夹 | 402×874 |
| `design/boards/iPhone-Codes.dc.html` | iPhone · 验证码 | 402×874 |
| `design/boards/iPhone-Generator.dc.html` | iPhone · 生成器 | 402×874 |
| `design/boards/iPhone-NewItem.dc.html` | iPhone · 新建条目 | 402×874 |
| `design/boards/iPhone-Settings.dc.html` | iPhone · 设置（标签页） | 402×874 |
| `design/boards/iPhone-AutoFill.dc.html` | iPhone · 自动填充 | 402×874 |
| `design/boards/iPhone-Send.dc.html` | iPhone · Send | 402×874 |
| `design/boards/iPhone-SendNew.dc.html` | iPhone · 新建 Send | 402×874 |
| `design/boards/iPhone-Trash.dc.html` | iPhone · 回收站与归档 | 402×874 |
| `design/boards/iPhone-ImportExport.dc.html` | iPhone · 导入与导出 | 402×874 |
| `design/boards/iPad-Login.dc.html` | iPad · 登录（账户与主密码 → 两步验证） | 1194×834 |
| `design/boards/iPad-Unlock.dc.html` | iPad · 解锁 | 1194×834 |
| `design/boards/iPad-Vault.dc.html` | iPad · 保险库（标签栏 / 侧边栏） | 1194×834 |
| `design/boards/iPad-Codes.dc.html` | iPad · 验证码 | 1194×834 |
| `design/boards/iPad-Search.dc.html` | iPad · 搜索 | 1194×834 |
| `design/boards/iPad-Send.dc.html` | iPad · Send | 1194×834 |
| `design/boards/iPad-Generator.dc.html` | iPad · 生成器 | 1194×834 |
| `design/boards/iPad-NewItem.dc.html` | iPad · 新建条目（表单页） | 1194×834 |
| `design/boards/iPad-Settings.dc.html` | iPad · 设置（标签页） | 1194×834 |
| `design/boards/Mac-Login.dc.html` | Mac · 登录（独立窗口：账户与主密码 → 两步验证） | 560×500 |
| `design/boards/Mac-Unlock.dc.html` | Mac · 解锁（触控 ID 或主密码） | 1280×800 |
| `design/boards/Mac-Vault.dc.html` | Mac · 主窗口 | 1280×800 |
| `design/boards/Mac-Codes.dc.html` | Mac · 验证码 | 1280×800 |
| `design/boards/Mac-Generator.dc.html` | Mac · 生成器 | 1280×800 |
| `design/boards/Mac-Edit.dc.html` | Mac · 新建条目（Sheet） | 1280×800 |
| `design/boards/Mac-Send.dc.html` | Mac · Send | 1280×800 |
| `design/boards/Mac-SendNew.dc.html` | Mac · 新建 Send（Sheet） | 600×600 |
| `design/boards/Mac-Trash.dc.html` | Mac · 归档与回收站 | 1280×800 |
| `design/boards/Mac-Import.dc.html` | Mac · 导入（Sheet） | 560×340 |
| `design/boards/Mac-Export.dc.html` | Mac · 导出（Sheet） | 560×500 |
| `design/boards/Mac-Settings.dc.html` | Mac · 设置窗口 | 720×330 |
| `design/boards/Mac-MenuBar.dc.html` | Mac · 菜单栏面板 | 380×560 |
| `design/boards/Spec.dc.html` | 设计规范 · Liquid Glass 规则、组件与 SwiftUI 对照 | 1600×5000 |
